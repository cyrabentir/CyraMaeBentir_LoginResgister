# Ionic Login Screen UI

## [Watch it on YouTube](https://youtu.be/18r03PpxtPk)

Mobile app Login Screen with ionic.
We design 3 screens first one is a welcome screen like then user open your app it shows then users have two options, if he has an account then press the login button and it just move him to the login screen or if he or she don't have an account then press signup button its direct to the signup screen.

### Preview

![App UI](/preview.png)